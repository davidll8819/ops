---
name: superpowers
description: 官方软件开发方法技能集：需求澄清、设计、计划、测试、调试和评审。
version: 7.0.0
---

# Superpowers

Source: https://github.com/obra/superpowers/tree/bb92a77741419a4ab5f06e711a283343f1ada0c3
License: MIT (LICENSE)

This package retains the official skills unchanged. Begin with skills/using-superpowers/SKILL.md, then load applicable skills and their references. Use only tools actually provided by the host.
